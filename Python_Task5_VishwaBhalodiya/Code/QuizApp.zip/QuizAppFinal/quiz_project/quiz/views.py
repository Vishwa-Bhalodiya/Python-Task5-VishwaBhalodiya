from django.shortcuts import render
from .models import Question

def quiz_view(request):
    questions = Question.objects.all()

    if request.method == 'POST':
        total = questions.count()
        correct = 0

        for question in questions:
            selected_option = request.POST.get(str(question.id))
            if selected_option:
                option_obj = question.options.get(id=int(selected_option))
                if option_obj.is_correct:
                    correct += 1

        wrong = total - correct
        return render(request, 'quiz/result.html', {
            'correct': correct,
            'wrong': wrong,
            'total': total
        })

    return render(request, 'quiz/quiz.html', {'questions': questions})
